package proj.TeamNull.UMLdevkkit;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class HomeControllerTest {

  @Test
  public void testHomePage() {
    assertEquals("expected", "actual");
  }
}
