# Format for posts in this Document:

- Date Start Time-End Time: Person(s) logging: Description of work

- 10/4/2024 1000-1500: John Doe: making this template 