# Format
- Date:10-10-2024
- Completed Work:All chapters and presentations for quiz
- Working On:Learning JSON, converting user story to scenario
- Problems/Setbacks: