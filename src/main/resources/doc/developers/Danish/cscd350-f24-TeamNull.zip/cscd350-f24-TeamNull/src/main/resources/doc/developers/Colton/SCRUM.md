# Format
- Date:
- Completed Work:
- Working On:
- Problems/Setbacks: