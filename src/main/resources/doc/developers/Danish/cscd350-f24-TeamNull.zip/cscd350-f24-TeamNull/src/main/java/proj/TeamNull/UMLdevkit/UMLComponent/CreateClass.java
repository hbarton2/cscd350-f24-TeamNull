package proj.TeamNull.UMLdevkit.UMLComponent;



import proj.TeamNull.UMLdevkit.Utility.ListClasses;
import proj.TeamNull.UMLdevkit.Utility.RenameClass;

import javax.xml.transform.Source;
import java.util.ArrayList;
import java.util.Scanner;

public class CreateClass {
    public void createClasses() {
        Scanner scanner = new Scanner(System.in);

        ArrayList<Object> allClasses = new ArrayList<>();
        String addNewClass = scanner.nextLine();

        while (addNewClass.equalsIgnoreCase("Create Class") || addNewClass.equalsIgnoreCase("yes")) {
            ArrayList<Object> classNameArray = new ArrayList<>();
            // Asking for class name
            System.out.print("Enter class name (or 'exit' to finish adding classes): ");
            String className = scanner.nextLine();
            if (className.equalsIgnoreCase("exit")) {
                break;
            }
            // Add class name to the classNameArray list
            classNameArray.add(className);
            // List to store field names
            ArrayList<Object> fieldsNameArray = new ArrayList<>();
            String fieldName;
            while (true) {
                System.out.print("Enter field name (or 'exit' to finish fields): ");
                fieldName = scanner.nextLine();
                if (fieldName.equalsIgnoreCase("exit")) {
                    break;
                }
                ArrayList<Object> fieldData = new ArrayList<>();
                fieldData.add(fieldName);
                fieldsNameArray.add(fieldData);
            }
            classNameArray.add(fieldsNameArray);
            // List to store method names
            ArrayList<Object> methodsList = new ArrayList<>();
            String methodName;
            while (true) {
                System.out.print("Enter method name (or 'exit' to finish methods): ");
                methodName = scanner.nextLine();
                if (methodName.equalsIgnoreCase("exit")) {
                    break;
                }
                ArrayList<Object> methodNameArray = new ArrayList<>();
                methodNameArray.add(methodName);
                methodsList.add(methodNameArray);
            }
            classNameArray.add(methodsList);
            allClasses.add(classNameArray);
            System.out.println("\nAll the information about " + className + " added.\n");
            System.out.println("Do you want to add another class?");
            addNewClass = scanner.nextLine();

        }
        System.out.println("Do you want to display all classes?");
        String userChoice = scanner.nextLine();
        if(userChoice.equalsIgnoreCase("yes")){
            ListClasses.display(allClasses);
        }
        System.out.println("End of class creation");

    }

}