package proj.TeamNull.UMLdevkit.Menu;

public class Menu {
  public String menu(){
    String menu = "\nWelcome to UML Class Editor Application\n" +
            "\nPlease Type a Command from List of Available Commands. Press Enter and Follow On Screen Prompts" +
            "\n------------------------------------------------------------------------------------------------"+
            "\nAvailable commands are:" +
            "\n......................."+
            "\n\n Command                      Usage\n" +

            "\n Create Class                 to create a new class"+
            "\n List Class                   to display all class on the screen." +
            "\n Rename Class                 to rename an existing class." +
            "\n Delete Class                 to delete an existing class." +
            "\n Exit                         to close the application, or you can click on the  type quit"+
            "\n"+
            "\n Type a command here: ";
    return menu;

  }

  public void displayMenu() {
    System.out.println("+-----------------------------+");
    System.out.println("|       Main Menu             |");
    System.out.println("+-----------------------------+");
    System.out.println("| 1. Help                     |");
    System.out.println("| 2. Settings                 |");
    System.out.println("| 3. About                    |");
    System.out.println("| 4. Exit                     |");
    System.out.println("+-----------------------------+");
    System.out.print("Enter your choice: ");
  }

  public void processInput(String input) {
    switch (input) {
      case "1":
        System.out.println("Help: This is a sample help message.");
        break;
      case "2":
        System.out.println("Settings: This is the settings section.");
        break;
      case "3":
        System.out.println("About: This application was built using JavaFX.");
        break;
      case "4":
        System.out.println("Exiting the menu...");
        System.exit(0);  // Terminate the application.
        break;
      default:
        System.out.println("Invalid choice. Please try again.");
    }

    displayMenu();  // Re-display the menu after processing input.
  }

}
